import React from 'react';
import Form from './ComponentA.jsx';
import Table from './ComponentB.jsx';


function App () {
  return(
        <div>
           <Form />
           <Table />
        </div>);
 }


export default App;


