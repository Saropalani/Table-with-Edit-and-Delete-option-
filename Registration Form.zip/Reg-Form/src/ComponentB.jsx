import React, { useContext } from "react";
import { useTable, useSortBy } from 'react-table';
import { FaSort } from 'react-icons/fa';
import { FaTrash, FaEdit } from 'react-icons/fa';
import { DataContext } from "./ComponentA";

function Table({ data, setData, editRow }) {


  if (!data || !Array.isArray(data)) {
    return null;
  }

  function deleteData(rowIndex) {
    console.log(rowIndex, "delete");
    let total = [...data];
    total.splice(rowIndex, 1);
    setData(total);
  }

  const handleEditRow = (rowData) => {
    editRow(rowData);
  };

const updateRow = (updatedRowData) => {
    if (index !== undefined && index !== null && index >= 0 && index < data.length) {
      const updatedData = [...data];
      updatedData[index] = updatedRowData; // Update the data at the specified index
      setData(updatedData); // Set the updated data state
    }
  };

  // Render table with edit and update functionality

  const columns = React.useMemo(
    () => [
      { Header: 'Employee Name', accessor: 'Employee Name' },
      { Header: 'Gender', accessor: 'Gender' },
      { Header: 'Department', accessor: 'Department' },
      { Header: 'Date of Join', accessor: 'Date of Join' },
      { Header: 'Email', accessor: 'Email' },
      {
        Header: 'Action',
        accessor: 'Action',
        disableSortBy: true,
        Cell: ({ row }) => (
          <div className="action">
            <FaTrash onClick={() => deleteData(row.index)} className="fa-trash" />
            <FaEdit onClick={() => handleEditRow(row.original)} className="fa-edit" />
          </div>
        )
      }
    ],
    [data, setData, editRow]
  );

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    rows,
    prepareRow,
  } = useTable(
    {
      columns,
      data,
    },
    useSortBy
  );

  return (
    <table
      id='table'
      className='table-container'
      style={{ display: data.length === 0 ? 'none' : 'table' }}
      {...getTableProps()}
    >
      <thead>
        {headerGroups.map((headerGroup) => (
          <tr {...headerGroup.getHeaderGroupProps()}>
            {headerGroup.headers.map((column) => (
              <th {...column.getHeaderProps(column.getSortByToggleProps())}>
                {column.render('Header')}
                {column.id !== 'Action' &&
                  (<span>
                    {column.isSorted ? (column.isSortedDesc ? '▼ ' : '▲') : <FaSort />}
                  </span>)}
              </th>
            ))}
          </tr>
        ))}
      </thead>
      <tbody {...getTableBodyProps()}>
        {rows.map((row, rowIndex) => {
          prepareRow(row);
          return (
            <tr key={rowIndex} {...row.getRowProps()}>
              {row.cells.map((cell, cellIndex) => (
                <td key={cellIndex} {...cell.getCellProps()}>
                  {cell.render('Cell')}
                </td>
              ))}
            </tr>
          );
        })}
      </tbody>
    </table>
  );
}

export default Table;
